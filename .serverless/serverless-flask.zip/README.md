# python_aws_serverless_tutorial
Repository containing codes on my first AWS project (REST API on Python using Flask)
